export const font = {
  Regular: 'Montserrat-Regular',
  Bold: 'Montserrat-Bold',
  Light: 'Montserrat-Light',
  SemiBold: 'Montserrat-SemiBold',
};
